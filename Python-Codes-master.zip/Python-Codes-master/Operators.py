#Operators

#Arithmetic operators

#consider
a = 10
b = 20


#Addition
a + b

#subtraction
a - b

#Multiplication
a * b

#division 
a/b

#Remove decimal (Floor Divison)
a//b
5.0//2
-11//3

#Modules
b % a


#exponential
a**b


#Comparision Operator

#It gives in bool values

a == b

a != b
 
a > b
 
a < b

a >= b

a <= b

#Assignment Operators

c = a+b
c
# c = c+b
c += b 

# c= c-b
c -= b

#c = c*a
c *= b

#c = c/a
c /= b

#c = c%a
c %= b


#c = c **a
c **= b

#c = c // a
c //= b



#Logical Operators

#Membership Operators

"i" in 'vinod'

"l" in "vinod"

"p" in "vinod"

"p" not in "Vinod"

#Identity Operators
"i" is "Vinod"

1 is 1
2 is 1
"vinod" is "Vinod"

1 is 0

1 is not 1

"hi hello"  is not  "hello hi"

