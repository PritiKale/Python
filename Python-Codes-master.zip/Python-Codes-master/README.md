# Python-Codes.
Basic to advance python codes with description.Their are some algorithms for data science.All codes are written in Spyder IDE and Goggle Collab.
