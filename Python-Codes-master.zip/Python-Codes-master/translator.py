# -*- coding: utf-8 -*-
"""
Created on Fri Sep  4 20:39:46 2020

@author: Immortal
"""


 from translate import Translator
       translator = Translator (from_lang = 'English',to_lang = 'German')
  result = translator.translate ('I Love You')
  print (result)
